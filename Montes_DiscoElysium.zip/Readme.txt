Pagina web diseñada por Pablo Montes Maya, 1º DAW

La web tiene 5 páginas de html y dos páginas de CSS

Todas las imagenes de la web son enlaces a la web discoelysium.fandom.com/wiki, 
por lo tanto para poder ver la web funcional, se ha de disponer de conexión a internet.

Las articulos de los personajes, los atributos y las localizaciones tienen hipervinculos en sus imagenes que llevan a la página
de la wiki donde se amplía la información.

La pagina a sido probada principalmente en Google Chrome, aun que no debería dar problemas en los demás navegadores.
Se han realizado pruebas en Edge, Mozilla y en Opera.

La barra de menu dispone de un @media que la transforma de horizontal a vertical al cerrarse la ventana a 700px o menos.

Tambien dispone de un @media el fondo de pantalla. Esta con un background-attachment: fixed; que hace quede fijo al fondo, 
pero al disminuir la pantalla empieza verse blanco por debajo, por lo que tiene un @media que cuando disminuye el tamaño de pantalla
a menos de 1700, el fondo pasa a repetirse.